package com.springboot.springresthib.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="library")
public class Library {
	
	//Create fields
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)//identification of primary key
	@Column(name="bookid")
    int bookid;
	
	@Column(name="booknames")
	String booknames;
	
	@Column(name="author")
	String author;
	
	@Transient
	private boolean disabled=true;
	
	
	//create constructors
	
	public Library()
	{
		
		
		
	}
	
public Library(String booknames,String author) {
		
		this.booknames=booknames;
		this.author=author;
		
		
	}
	
	//generate getter and setter
	
	
	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}

	public String getBooknames() {
		return booknames;
	}

	public void setBooknames(String booknames) {
		this.booknames = booknames;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
	
	//generate toString
		@Override
		public String toString() {
			return"BookId=" + bookid + ",BookNames=" + booknames + ",Author=" + author + "]";
		}

		public boolean isDisabled() {
			return disabled;
		}

		public void setDisabled(boolean disabled) {
			this.disabled = disabled;
		}

		
	
	
	
	
	
	
	
	
	
}

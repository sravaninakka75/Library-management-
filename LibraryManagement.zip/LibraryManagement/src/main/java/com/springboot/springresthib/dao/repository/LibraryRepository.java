package com.springboot.springresthib.dao.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.springresthib.entity.Library;

public interface LibraryRepository extends JpaRepository<Library, Integer> {



	

}

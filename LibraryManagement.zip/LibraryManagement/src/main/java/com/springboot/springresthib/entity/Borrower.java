package com.springboot.springresthib.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="borrower")

public class Borrower {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)//identification of primary key
	@Column(name="id")
	int id;
	@Column(name="personname")
	String personname;
	@Column(name="emailid")
	String emailid;
	

	
	public Borrower()
	{
		
		
		
	}
	
public Borrower(String personname,String emailid){

	
	this.personname=personname;
	this.emailid=emailid;
	
		
		
	}

	public  int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPersonname() {
		return personname;
	}
	public void setPersonname(String personname) {
		this.personname = personname;
	}
	
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	
	
	//generate toString
			@Override
			public String toString() {
				return"Borrowerid=" + id + ",PersonName=" + personname + ",Email=" +emailid +"]";
			}


}

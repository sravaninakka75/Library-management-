package com.springboot.springresthib.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.springresthib.dao.repository.BorrowerRepository;
import com.springboot.springresthib.dao.repository.LibraryRepository;
import com.springboot.springresthib.entity.Borrower;
import com.springboot.springresthib.entity.Library;


@Service

public class LibraryServiceImpl implements LibraryService {
	
	private LibraryRepository libraryRepository;
	private BorrowerRepository borrowerRepository;
	
	//@Autowired
	//public LibraryServiceImpl ( BorrowerRepository borrowerRepository) {
		//this.borrowerRepository=borrowerRepository;
		
	//}
	@Autowired
	public LibraryServiceImpl ( LibraryRepository libraryRepository,BorrowerRepository borrowerRepository) {
		this.libraryRepository=libraryRepository;
		this.borrowerRepository=borrowerRepository;
		
	}

	@Override
	public List<Library> getAllBooks() {
		
		return libraryRepository.findAll();
	}

	@Override
	public void addbook(Library addbook) {
		 libraryRepository.save(addbook);
	}

	@Override
	public Library getBookById(int bookid) {
		Library book=null;
	Optional<Library>book1=libraryRepository.findById( bookid);
	return book=book1.get();
			
	}

	@Override
	public void deleteBook(int bookid) {
		libraryRepository.deleteById(bookid);
		
	}

	@Override
	public void addBorrowerDetails(Borrower borrower) {
		
		borrowerRepository.save(borrower);
	}

	@Override
	public List<Borrower> getAllBorrowers() {
		return borrowerRepository.findAll();
	}

	@Override
	public Borrower getBorrowerById(int id) {
		Borrower borrower=null;
		Optional<Borrower>borrower1=borrowerRepository.findById( id);
		return borrower=borrower1.get();
	}

	@Override
	public void deleteBorrower(int id) {
		borrowerRepository.deleteById(id);
		
		
	}

}

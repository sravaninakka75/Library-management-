package com.springboot.springresthib.dao.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.springboot.springresthib.entity.Borrower;

@EnableJpaRepositories
public interface BorrowerRepository extends JpaRepository<Borrower, Integer> {


	

}

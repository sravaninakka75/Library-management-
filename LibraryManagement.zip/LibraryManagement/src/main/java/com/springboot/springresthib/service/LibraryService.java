package com.springboot.springresthib.service;

import java.util.List;

import com.springboot.springresthib.entity.Borrower;
import com.springboot.springresthib.entity.Library;

public interface LibraryService {
	
	public List<Library> getAllBooks();
	public void addbook(Library addbook);
    public Library getBookById(int bookid);
    public void deleteBook(int bookid);
    public List<Borrower> getAllBorrowers();
    public void addBorrowerDetails(Borrower borrower);
    public Borrower getBorrowerById(int id);
    public void deleteBorrower(int id);
   
}
/*//get all books

@RequestMapping("/AllBooks")

public List<Library> getAllBooks() {
	
	return libraryService.getAllBooks();
}

//to add a book

@RequestMapping(value="/AddBooks", method=RequestMethod.POST)
public Library addbook(@RequestBody Library book) {
	//emp.setId(0);
	libraryService.addbook(book);
	return book;
}

//to get a book by id

	@GetMapping ("/AllBooks/{bookId}")
	public Library getBookById(@PathVariable int  bookId) {
		System.out.println("hi");
	Library book=libraryService.getBookById( bookId);
	System.out.println("hi");
	return book;
	}
	
	
	//To delete a book
	@RequestMapping(value="/AllBooks/{bookId}", method=RequestMethod.DELETE)

	public String deleteBook(@PathVariable int bookId) {
		Library book2=libraryService.getBookById( bookId);
		libraryService.deleteBook(bookId);
		return "Deleted Book is :" +bookId;
		
	}
	
	//TO update a book
	
	@RequestMapping(value="/AllBooks/update", method=RequestMethod.PUT)
	public Library updateBook(@RequestBody Library book) {
		libraryService.addbook(book);
		return book ;
	}*/
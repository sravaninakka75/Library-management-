package com.springboot.springresthib.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.springresthib.entity.Borrower;
import com.springboot.springresthib.entity.Library;
import com.springboot.springresthib.service.LibraryService;

@Controller
@RequestMapping("/api")
public class LibraryController {
	Boolean flag=true;
	
	@RequestMapping("/h")
	public  String hello() {
		return "hello baby";
	}
	
	
	
		
	
	private LibraryService libraryService;
	@Autowired
	public LibraryController(LibraryService libraryService) {
		this.libraryService=libraryService;
	}
	
	
	//Handler method for thymeleaf
		@RequestMapping("/welcome")
		public String helloThymeLeaf(Model theModel) {
			theModel.addAttribute("theDate",new java.util.Date());
			return "Thymeleaf";
		}
	
		//To Get AllBooks
		@RequestMapping("/AllBooks")
		public String getAllBooksList(Model theModel) {
			theModel.addAttribute("theBooks",libraryService.getAllBooks());
			return "bookslist";
		}
		
		
		@RequestMapping(value="/showaddbooks", method=RequestMethod.GET)
		public String showformforadd(Model theModel) {
			//System.out.println("in show form");
			Library theBook=new Library();
			theModel.addAttribute("book",theBook);
			return "bookaddpage";
		}
		
		//To Add A Book
		@RequestMapping (value ="/savebook",method=RequestMethod.POST)//post will add employee
		public String saveBook (@ModelAttribute ("book") Library AddBook ) {
			System.out.println("in save emp method"+AddBook.getBookid()); 
			libraryService.addbook (AddBook);
			return "redirect:/api/AllBooks";
			
		}
		
		
		@RequestMapping(value="/showbooksupdated")
		public String updateBooks(@RequestParam("bookId")int bookid,Model theModel) {
			System.out.println("bookid in update"+bookid); 
			Library updatebook=libraryService.getBookById(bookid);
			theModel.addAttribute("book",updatebook);
			return"bookaddpage";
		}
		@RequestMapping(value ="/showbooksdeleted") 
		public String deleteBook (@RequestParam ("bookId") int bookid)
		{
		System.out.println("bookid in delete "+bookid);
		libraryService.deleteBook(bookid);
		return"redirect:/api/AllBooks"; 
		}
		
		
		@RequestMapping("/AllBorrowers")
		public String getAllBorrowersList(Model theModel) {
			theModel.addAttribute("theBorrower",libraryService.getAllBorrowers());
			return "borrowerlist";
		}
		
		@RequestMapping(value="/addborrowers", method=RequestMethod.GET)
		public String showaddborrowers(Model theModel) {
			//System.out.println("in show form");
			Borrower borrower=new Borrower();
			theModel.addAttribute("borrower",borrower);
			return "borroweraddform";
		
		/*@RequestMapping(value="/addborrowers", method=RequestMethod.GET)
		public String showaddborrowers(Model theModel) {
			//System.out.println("in show form");
			Borrower theBorrower=new Borrower();
			theModel.addAttribute("borrower",theBorrower);
			return "borroweraddform";*/
		}
		
		@RequestMapping (value ="/saveborrower",method=RequestMethod.POST)//post will add employee
		public String saveBorrower (@ModelAttribute ("borrower") Borrower AddBorrower ) {
			//System.out.println("in save BorrowerDetails method"+Borrower.getById());
			libraryService.addBorrowerDetails (AddBorrower);
			flag=false;
			return "redirect:/api/AllBorrowers";
		
		}
		@RequestMapping(value ="/showborrowersdeletedreturned") 
		public String returnBorrower (@RequestParam ("borrowerreturnId") int id)
		{
		System.out.println("borrowerreturnId in delete "+id);
		libraryService.deleteBorrower(id);
		return"redirect:/api/AllBorrowers"; 
		}
		
		/*@GetMapping("/AllBooks/{bookid}")
		public String example(@PathVariable("bookid") int bookid, Model model) {
		    Library library = libraryService.getBookById(bookid);
		    library.setDisabled(false);
		    model.addAttribute("library", libraryService.getBookById(bookid));
		    return "bookslist";
		}*/
		
		
		
		
}
/*@RequestMapping(value ="/openborrowerform") 
public String openborrowerpage() {
	System.out.println("are in borrower form");
	return "borroweraddform";
}*/

/*@RequestMapping (value ="/saveBorrowersDetails",method=RequestMethod.POST)//post will add employee
public String saveBook (@ModelAttribute ("borrower") Borrower addborrower ) {
	//System.out.println("in save borower method"+addborrower.getBookid()); 
	libraryService.addBorrowerDetails (addborrower);
	//flag=false;
	return "redirect:/api/AllBooks";
	
}
*/
		
		

